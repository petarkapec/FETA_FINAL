export type Narudzba = {
    narudzba_id: number,
    sesija_id: number,
    korisnik: number,
    comment: string,
    donation: number,
    nickname: string,
    song_id: number,
    song_name: string,
    song_artist: string,
    song_album_art: string,
    status: string,
    stripe_payment_link: string
    }