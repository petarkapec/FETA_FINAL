export type Sesija = {
    sesija_id: number,
    dj_id: number,
    lokacija_id: number,
    expiration: string,
    minimal_price: number,
    comentary: string,
    queue_max_song_count: number,
    naziv: string,
  }
