export type Song = {
  id: string
  name: string
  artist: string
  albumArt: string
}
