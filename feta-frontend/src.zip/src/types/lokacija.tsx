export type Lokacija = {
  lokacija_id: number
  profil_slika_link: string
  facebook: string
  instagram: string
  twitter: string
  about_us: string
  adresa: string
  email: string
  broj_telefona: string
  naziv_kluba: string
}
